import sys
def main():
    l = []
    for line in sys.stdin:
        l.append(line)
    print(l)
class Tablica:
	pocetno_stanje = 'S_pocetno'
	Reg_def = {'znamenka': '0|1|2|3|4|5|6|7|8|9', 'hexZnamenka': '(0|1|2|3|4|5|6|7|8|9)|a|b|c|d|e|f|A|B|C|D|E|F', 'broj': '(0|1|2|3|4|5|6|7|8|9)(0|1|2|3|4|5|6|7|8|9)*|0x((0|1|2|3|4|5|6|7|8|9)|a|b|c|d|e|f|A|B|C|D|E|F)((0|1|2|3|4|5|6|7|8|9)|a|b|c|d|e|f|A|B|C|D|E|F)*', 'bjelina': '\\t|\\n|\\_', 'sviZnakovi': '\\(|\\)|\\{|\\}|\\||\\*|\\\\|\\$|\\t|\\n|\\_|!|"|#|%|&|\'|+|,|-|.|/|0|1|2|3|4|5|6|7|8|9|:|;|<|=|>|?|@|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|[|]|^|_|`|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|~'}
	Imena = ['OPERAND', 'OP_MINUS', 'UMINUS', 'LIJEVA_ZAGRADA', 'DESNA_ZAGRADA']
	prijelazi = {'S_pocetno': [['\\t|\\_', '-'], ['\\n', '-', 'NOVI_REDAK'], ['#\\|', '-', 'UDJI_U_STANJE S_komentar'], ['((0|1|2|3|4|5|6|7|8|9)(0|1|2|3|4|5|6|7|8|9)*|0x((0|1|2|3|4|5|6|7|8|9)|a|b|c|d|e|f|A|B|C|D|E|F)((0|1|2|3|4|5|6|7|8|9)|a|b|c|d|e|f|A|B|C|D|E|F)*)', 'OPERAND'], ['\\(', 'LIJEVA_ZAGRADA'], ['\\)', 'DESNA_ZAGRADA'], ['-', 'OP_MINUS'], ['-(\\t|\\n|\\_)*-', 'OP_MINUS', 'UDJI_U_STANJE S_unarni', 'VRATI_SE 1'], ['\\((\\t|\\n|\\_)*-', 'LIJEVA_ZAGRADA', 'UDJI_U_STANJE S_unarni', 'VRATI_SE 1']], 'S_komentar': [['\\|#', '-', 'UDJI_U_STANJE S_pocetno'], ['\\n', '-', 'NOVI_REDAK'], ['(\\(|\\)|\\{|\\}|\\||\\*|\\\\|\\$|\\t|\\n|\\_|!|"|#|%|&|\'|\\+|,|-|\\.|/|0|1|2|3|4|5|6|7|8|9|:|;|<|=|>|\\?|@|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|[|]|\\^|_|`|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|~)', '-']], 'S_unarni': [['\\t|\\_', '-'], ['\\n', '-', 'NOVI_REDAK'], ['-', 'UMINUS', 'UDJI_U_STANJE S_pocetno'], ['-(\\t|\\n|\\_)*-', 'UMINUS', 'VRATI_SE 1']]}
if __name__ == "__main__":
    main()
